<?php 
include("view/top.php"); ?>

<div class="container">  
     <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
          <h5><i class="bi bi-check-circle-fill"></i> ĐƠN HÀNG SẼ ĐƯỢC XỬ LÝ TRONG THỜI GIAN SỚM NHẤT. CÁM ƠN BẠN ĐÃ ĐẶT HÀNG!</h5>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
               <span aria-hidden="true">&times;</span>
          </button>
     </div>
     <hr>
     <h2>Sản phẩm nổi bậc</h2>
     <?php include("topview.php"); ?>
</div>

<?php include("view/bottom.php"); ?>