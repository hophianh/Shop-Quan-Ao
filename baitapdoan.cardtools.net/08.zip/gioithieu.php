<?php include("view/top.php"); ?>

<div class="container">  
    <h3><b>GIỚI THIỆU VỀ NUTY</b> </h3>
 

  
    <p class="mark">Nuty Cosmetics tự hào là một trong những chuỗi cửa hàng mỹ phẩm lớn và đáng tin cậy nhất tại Long Xuyên, nơi có thể thỏa mãn niềm đam mê trong cuộc chơi phấn son của hàng triệu tín đồ yêu shopping từ Nam ra Bắc. Được ưu ái với tên gọi “Thiên Đường Mỹ Phẩm Triệu Like”, Nuty luôn được xem là mái nhà chung của hàng nghìn mặt hàng mỹ phẩm thuộc rất nhiều thương hiệu lớn nhỏ, hội tụ từ khắp các quốc gia trên thế giới. Nuty luôn sẵn sàng đáp ứng mọi nhu cầu làm đẹp cho phái đẹp lẫn phái mạnh mà không cần phải lo về giá và chất lượng sản phẩm.</p>  
    <p>Nuty tự hào là shop luôn “đi tắt đón đầu”, cập nhật xu hướng mỹ phẩm nhanh nhất để “chiều lòng” tất cả các tín đồ mê làm đẹp. Hàng hóa đa dạng từ Âu sang Á cam kết chính hãng 100%, có bill cho bạn kiểm chứng hoặc bạn có thể thoải mái check code ngay tại shop.</p>
    <p>Luôn mang đến cho khách hàng mức giá yêu thương nhất nên dù túi tiền của bạn có “eo hẹp” đến đâu cũng sẽ dễ dàng lựa chọn cho mình một sản phẩm “ưng bụng”. Đặc biệt, cho đến thời điểm hiện tại Nuty cũng đã hợp tác thành công và trở thành đại lý phân phối chính thức của 15 “ông trùm” mỹ phẩm đình đám như Paula’s Choice, Vichy, Bioderma, La Roche-Posay, Murad… cùng hàng chục thương hiệu nổi tiếng khác. Cũng nhờ thế mà lượng hàng hóa tại Nuty luôn luôn phong phú, đa dạng đồng thời cam kết đảm bảo uy tín chất lượng.</p>
    <h3><b>THÔNG TIN LIÊN HỆ</b> </h3>
    <p>Quý khách có nhu cầu liên lạc, trao đổi hoặc đóng góp ý kiến, vui lòng tham khảo các thông tin sau:</p>
    <p>- Liên lạc qua điện thoại: 0368672641</p>
    <p>- Liên lạc qua email: tnhuy2000@gmail.com</p>
    <p>- Địa chỉ: Tây Bình A, Vĩnh Chánh,Thoại Sơn, An Giang</p>
    <p>Fanpage của Nuty: http://facebook.com/nuty.vn</p>
    <p class="mark">Với phương châm hoạt động “Tất cả vì Khách Hàng”, Nuty luôn không ngừng nỗ lực nâng cao chất lượng dịch vụ và sản phẩm, từ đó mang đến trải nghiệm mua sắm trọn vẹn cho Khách Hàng Việt Nam với dịch vụ giao hàng nhanh trong 2 tiếng, cùng cam kết cung cấp hàng chính hãng với chính sách hoàn tiền 111% nếu phát hiện hàng giả, hàng nhái.</p>

 
    

 
</div>
<br>
   
<?php include("view/bottom.php"); ?>
  
