<!DOCTYPE html>
<html>
<head>
  	<title>Đăng ký</title>
	<link href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet"> 
  	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
	  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
	<style>
		body{
			background-color: #83b9f2;
		}
	</style>
	<script src="public/js/shop.js"></script>
</head>
<body>
		<nav class="navbar navbar-light bg-light sticky-top">
			<div class="container">
				<a class="navbar-brand" href="index.php">
					<img src="public/images/logo1.png" width="100" height="40" class="d-inline-block align-top" alt="" />
					<b>Đăng ký</b></a>
			</div>
		</nav>
	<br>
	<div class="container">
		<div class="row">
			<div class="col-sm-3">

			</div>
			<div class="col-sm-6">
				
			</div>
		</div>
	</div>

</body>
</html>