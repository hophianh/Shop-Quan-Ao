

  function ktxacnhanmatkhau() {
    var matkhau = document.getElementById("matkhau").value;
    var xacnhanmatkhau = document.getElementById("xacnhanmatkhau").value;
    if (matkhau == xacnhanmatkhau) {
      return true;
    } else {
      alert("Xác nhận mật khẩu thất bại!");
      return false;
    }
  }
  


  // =================================================
  // Banner (đổi ảnh banner sau 3 giây)
//phân trang
  
  