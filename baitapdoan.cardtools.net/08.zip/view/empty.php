    <h5>GIỎ HÀNG</h5> 
		<div class="alert alert-danger alert-dismissible fade show mb-0" role="alert">
            <i class="bi bi-cart-x-fill"></i> <?php echo $message; ?>
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
        <br>
        <div class="text-center" height="400px">
            <img src="public/images/giohangrong.png" width="200px" alt="">
            <br><br>
            <p>Không có sản phẩm nào trong giỏ hàng của bạn.</p>
            <a href="index.php?action=macdinh" class="btn btn-warning">Tiếp tục mua sắm</a>
        </div>
        <br>
