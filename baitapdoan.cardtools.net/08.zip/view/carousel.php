<div class="container">
  <table>
    <tr>
      <th style="padding-right:5px">
        <div id="carouselExampleCaptions" class="carousel slide carousel-fade" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="3"></li>
        
          </ol>
          <div class="carousel-inner">
          
            <div class="carousel-item active">
              <img src="public/images/carousel/c8.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item ">
              <img src="public/images/carousel/c6.png" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item ">
              <img src="public/images/carousel/c4.png" class="d-block w-100" alt="...">
            </div>
            
            <div class="carousel-item">
              <img src="public/images/carousel/c2.jpg" class="d-block w-100" alt="...">
              
            </div>
            <div class="carousel-item">
              <img src="public/images/carousel/c10.png" class="d-block w-100" alt="...">
              
            </div>
            <div class="carousel-item">
              <img src="public/images/carousel/c9.jpg" class="d-block w-100" alt="...">
              
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </th>
      <th >
      <img src="public/images/carousel/c6.jpg" width="200 px" height="270 px" alt="...">
      </th>
    </tr>  
  </table>
</div>






